
export default function Home() {
  return <div>Welcome to NeuroNexa</div>;
}
