# NeuroNexa

**NeuroNexa** – Where Thought Becomes Command.  
Forge elite prompts and build AI power tools.

This is a static Next.js site built for Netlify deployment.

## Scripts

- `npm run dev` — Local development
- `npm run build` — Build for production
- `npm run export` — Export as static HTML for Netlify

## Deploy

Set the following in Netlify:

- **Build Command**: `npm run export`
- **Publish Directory**: `out`
